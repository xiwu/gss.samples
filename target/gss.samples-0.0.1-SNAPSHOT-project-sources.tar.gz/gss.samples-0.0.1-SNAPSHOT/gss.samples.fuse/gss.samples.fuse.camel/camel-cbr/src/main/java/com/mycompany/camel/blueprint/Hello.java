package com.mycompany.camel.blueprint;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
